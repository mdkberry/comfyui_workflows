I am releasing these wip now as I am away for a bit.

June I was testing Bernini for structure (which I love) (5 or 10 seconds but I was doing 5 for music video)

July I was working on upscaling that, while maintaining character consistency but unfortunately hadnt solved it yet (without resorting to FF, LF).

but was getting best results with a new apporach using IC union Lora and the original Bernini video passed in to this `3d. MBEDIT - LTX23_IC-Ctrl-Union-Lora_Detailer-Upscaler_v2` while using a single frame FF to drive it and the same prompt used in Bernini.

Scail 2 is also really good and making think about new approach to dialogue using acting filmed on android.

Now, I need some R&R. I'll continue with all wip when back sometime around 20th July. 

Mark, 9th July 2026.