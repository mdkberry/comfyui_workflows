# STEPS FOR GETTING ANIMATION OUT OF MOTION IN VIDEO FILE AND SAVING IT TO MIXAMO FBX FILE

NOTE: do this on 1 person at a time not multiple people

## 1. SAM3 masking to target a single person in the clip

workflow: "1. MBEDIT - SAM3-utility_video_segment_v4.json"

NOTE: SAM3 is native to comfyui now

NOTE: you probably need to have complete view of the person, no legs or arms behind someone else for this to work. (not always it turns out)

- I set the video to 10 seconds and 832 on the longer edge